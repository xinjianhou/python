def print_lol(the_list,level):
	'''来循环遍历集合，打印出集合里的每一样东西
	'''
	# 传入一个集合
	for iteam in the_list:
		if isinstance(iteam,list):
			print_lol(iteam,level+1);
		else:
			for tab_stop in range(level):
				print('\t',end='')
			print(iteam);
