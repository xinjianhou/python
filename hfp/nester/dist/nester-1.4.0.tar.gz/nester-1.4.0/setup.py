from distutils.core import setup

setup(

		name        = 'nester',
		version     = '1.4.0',
		py_modules  = ['nester'],
		author      = 'xinjianhou',
		author_email= 'houxinian7@outlook.com',
		url         = 'www.github.xinjianhou.com',
		description = 'A simple printer for nester list',

		)